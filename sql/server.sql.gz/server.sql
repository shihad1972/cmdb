-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server` (
  `server_id` int(7) NOT NULL AUTO_INCREMENT,
  `vendor` varchar(50) DEFAULT NULL,
  `make` varchar(50) DEFAULT NULL,
  `model` varchar(30) DEFAULT NULL,
  `uuid` varchar(50) DEFAULT NULL,
  `cust_id` int(7) DEFAULT NULL,
  `vm_server_id` int(7) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`server_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
INSERT INTO `server` VALUES (1,'KVM','Virtual Machine','x86_64','e33a6da1-dc59-365e-c36b-52bfb2757562',1,1,'aberdeen'),(2,'KVM','Virtual Machine','x86_64','3a96479f-6387-3dea-2ae1-eef75995b6bf',1,1,'celtic'),(3,'KVM','Virtual Machine','x86_64','709c35ec-f797-4fc0-cb7e-3a68f63935dd',1,1,'dundee'),(5,'KVM','Virtual Machine','x86_64','ff1e94ed-d081-e557-fb69-c9e73127ba77',1,1,'hibernian'),(6,'KVM','Virtual Machine','x86_64','4635b740-f996-51d7-105d-6762b4fe9fbc',1,1,'inverness'),(7,'KVM','Virtual Machine','x86_64','9df49c05-6213-6eda-4c55-1294e1d1ff27',1,1,'kilmarnock'),(9,'Dell','Poweredge','2950','HGTTDYJ',3,1,'st-mirren'),(10,'KVM','Virtual Machine','x86_64','3f428da6-d32c-d680-669b-e7ec00b0adfb',3,1,'rangers'),(11,'KVM','Virtual Machine','x86_64','caa7a9bf-f946-e95c-ec28-145bd22fe800',2,1,'hamilton'),(12,'KVM','Virtual Machine','x86_64','a8f41f08-8f5e-9104-c40e-21e51be3c53b',1,1,'motherwell'),(16,'GlobalPC','Homemade','x86_64','GeForce8200',2,1,'shihad'),(20,'KVM','Virtual Machine','X86_64','9daa24de-599b-50c1-861f-9d5baee98655',2,1,'dunfermline'),(22,'KVM','Virtual Machine','X86_64','b9dde850-0fb3-4954-adf1-8b63fedd0b5e',2,1,'falkirk'),(24,'Global PC','Nvidia','MCP61','a8c00e01',1,1,'weezer'),(25,'HP','LC','2000','KDF76H5',3,1,'morton'),(26,'KVM','Virtual Machine','x86_64','7538f01e-c751-fc4b-4073-b782566c220c',2,1,'livingston'),(29,'KVM','Virtual Machine','x86_64','c88f1230-e1c6-98b9-aa46-f91b05e6fc1a',5,2,'bolton'),(30,'KVM','Virtual Machine','x86_64','d9af3d28-70c8-73d4-cec4-f934c31cf7f3',5,2,'chelsea'),(31,'KVM','Virtual Machine','x86_64','5c825859-f56a-ed17-58f9-bd0e759a0329',5,2,'liverpool'),(33,'KVM','Virtual Machine','x86_64','4e2bd2cb-e72e-6ace-8d46-91cb37490d51',5,2,'everton'),(35,'KVM','Virtual Machine','x86_64','65a7cac4-16d4-db0f-3921-51b3f54712ab',2,1,'montrose'),(36,'KVM','Virtual Machine','x86_64','84f0a8b9-4484-bbdf-8b21-4579031cc75a',2,2,'newcastle'),(41,'KVM','Virtual Machine','x86_64','c88f1230-e1c6-98b9-aa46-f91b05e6fc1a',7,2,'reading'),(42,'KVM','Virtual Machine','x86_64','2f5f7489-3cc0-770a-0dd6-789ff968c577',7,2,'arsenal'),(43,'KVM','Virtual Machine','x86_64','ca10f973-a0ec-9bb1-07c1-1630bff5964a',7,2,'sunderland');
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:05
