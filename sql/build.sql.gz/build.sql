-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `build`
--

DROP TABLE IF EXISTS `build`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build` (
  `build_id` int(7) NOT NULL AUTO_INCREMENT,
  `mac_addr` varchar(17) DEFAULT NULL,
  `varient_id` int(7) DEFAULT NULL,
  `net_inst_int` varchar(12) DEFAULT NULL,
  `server_id` int(7) DEFAULT NULL,
  `os_id` int(7) DEFAULT NULL,
  `boot_id` int(7) DEFAULT NULL,
  `ip_id` int(7) DEFAULT NULL,
  `locale_id` int(7) NOT NULL,
  PRIMARY KEY (`build_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `build`
--

LOCK TABLES `build` WRITE;
/*!40000 ALTER TABLE `build` DISABLE KEYS */;
INSERT INTO `build` VALUES (32,'52:54:00:d1:36:a7',10,'eth0',1,40,2,36,2),(33,'52:54:00:73:d7:bf',1,'eth0',5,40,2,37,2),(38,'52:54:00:26:4d:2f',4,'eth0',20,50,14,41,0),(40,'52:54:00:09:af:86',7,'eth0',22,48,14,43,0),(44,'52:54:00:66:d4:e9',4,'eth0',2,40,2,45,2),(46,'52:54:00:4b:a1:0d',5,'eth0',3,40,2,46,2),(47,'52:54:00:c1:e1:5d',5,'eth0',10,40,2,47,2),(48,'52:54:00:05:06:69',2,'eth0',6,56,16,48,0),(49,'00:1d:7d:5c:69:fb',2,'eth0',24,40,2,49,2),(50,'52:54:00:08:ca:81',5,'eth0',7,40,2,50,2),(51,'52:54:00:9d:80:da',5,'eth0',26,40,2,51,2),(52,'52:54:00:af:b7:23',10,'eth0',12,40,2,52,2),(54,'52:54:00:ac:ec:17',4,'eth0',29,40,2,54,2),(55,'52:54:00:7c:54:c8',2,'eth0',30,40,2,55,2),(57,'52:54:00:11:a9:e5',5,'eth0',33,40,2,57,2),(58,NULL,NULL,NULL,16,NULL,NULL,58,0),(60,'52:54:00:61:32:ec',1,'eth0',35,53,2,60,0),(61,'52:54:00:ee:cf:e9',4,'eth0',36,40,2,61,2),(68,'52:54:00:e3:af:d2',1,'eth0',31,40,2,72,2),(79,'52:54:00:7d:47:2a',2,'eth0',11,43,10,83,24),(80,'52:54:00:c5:f6:1f',1,'eth0',42,43,10,84,24),(81,'52:54:00:ca:17:f0',1,'eth0',43,43,10,85,24);
/*!40000 ALTER TABLE `build` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:04
