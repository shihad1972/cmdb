-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `records`
--

DROP TABLE IF EXISTS `records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone` int(11) NOT NULL DEFAULT '0',
  `host` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `pri` int(11) NOT NULL DEFAULT '0',
  `destination` varchar(255) NOT NULL,
  `valid` varchar(255) NOT NULL DEFAULT 'unknown',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `records`
--

LOCK TABLES `records` WRITE;
/*!40000 ALTER TABLE `records` DISABLE KEYS */;
INSERT INTO `records` VALUES (5,4,'aberdeen','A',0,'192.168.1.120','yes'),(6,4,'celtic','A',0,'192.168.1.121','yes'),(9,4,'dundee','A',0,'192.168.1.129','yes'),(10,4,'dunfermline','A',0,'192.168.1.133','yes'),(11,4,'falkirk','A',0,'192.168.1.135','yes'),(12,4,'hamilton','A',0,'192.168.1.131','yes'),(13,4,'@','MX',15,'mail02.scots.shihad.org.','yes'),(14,4,'mail01','A',0,'192.168.1.140','yes'),(15,4,'mail02','A',0,'192.168.1.141','yes'),(16,4,'@','MX',10,'mail01.scots.shihad.org.','yes'),(17,4,'@','A',10,'192.168.1.130','yes'),(20,5,'mail','A',0,'192.168.1.11','yes'),(22,12,'ns1','A',0,'192.168.1.120','yes'),(23,12,'ns2','A',0,'192.168.1.122','yes'),(24,12,'mail','A',0,'192.168.1.140','yes'),(26,12,'ftp','A',0,'192.168.1.130','yes'),(27,13,'ns1','A',0,'192.168.1.120','yes'),(28,13,'ns2','A',0,'192.168.1.122','yes'),(29,13,'mail','A',0,'192.168.1.140','yes'),(30,13,'www','A',0,'192.168.1.130','yes'),(31,13,'ftp','A',0,'192.168.1.130','yes'),(32,13,'@','MX',10,'mail.build.thargoid.co.uk.','yes'),(33,15,'ns1','A',0,'192.168.1.120','yes'),(34,15,'ns2','A',0,'192.168.1.122','yes'),(37,15,'ftp','A',0,'192.168.1.130','yes'),(38,15,'@','MX',10,'mail.thargoid.co.uk.','yes'),(39,16,'ns1','A',0,'192.168.1.120','yes'),(40,16,'ns2','A',0,'192.168.1.122','yes'),(41,16,'mail','A',0,'192.168.1.140','yes'),(42,16,'www','A',0,'192.168.1.130','yes'),(43,16,'ftp','A',0,'192.168.1.130','yes'),(44,16,'@','MX',10,'mail.freesoftwareconsultancy.com.','yes'),(45,17,'ns1','A',0,'192.168.1.120','yes'),(46,17,'ns2','A',0,'192.168.1.122','yes'),(47,17,'mail','A',0,'192.168.1.140','yes'),(48,17,'www','A',0,'192.168.1.130','yes'),(49,17,'ftp','A',0,'192.168.1.130','yes'),(50,17,'@','MX',10,'mail.epl.shihad.org.','yes'),(51,18,'ns1','A',0,'192.168.1.120','yes'),(52,18,'ns2','A',0,'192.168.1.122','yes'),(53,18,'mail','A',0,'192.168.1.140','yes'),(54,18,'www','A',0,'192.168.1.130','yes'),(55,18,'ftp','A',0,'192.168.1.130','yes'),(56,18,'@','MX',10,'mail.fsc.net.','yes'),(59,15,'build','A',0,'192.168.1.10','unknown'),(60,15,'iain','A',0,'192.168.1.10','unknown'),(61,15,'iza','A',0,'192.168.1.11','unknown'),(62,15,'movies','A',0,'192.168.1.15','unknown'),(63,15,'setup','A',0,'192.168.1.20','unknown'),(64,5,'rialto','A',0,'192.168.1.1','unknown'),(65,5,'spacer','A',0,'192.168.1.2','unknown'),(66,5,'brasco','A',0,'192.168.1.3','unknown'),(67,5,'basque','A',0,'192.168.1.4','unknown'),(68,5,'feeder','A',0,'192.168.1.5','unknown'),(69,5,'primus','A',0,'192.168.1.6','unknown'),(70,5,'acid','A',0,'192.168.1.7','unknown'),(71,5,'arctic','A',0,'192.168.1.8','unknown'),(74,4,'ns1','A',0,'192.168.1.120','unknown'),(75,5,'ns1','A',0,'192.168.1.120','unknown'),(76,5,'ns2','A',0,'192.168.1.122','unknown'),(77,4,'ns2','A',0,'192.168.1.122','unknown'),(78,12,'build','A',0,'192.168.1.10','unknown'),(79,5,'apache','A',0,'192.168.1.70','unknown'),(80,5,'cmdb','A',0,'192.168.1.21','unknown'),(81,5,'cmdb-dev','A',0,'192.168.1.20','unknown'),(82,5,'debian','A',0,'192.168.1.48','unknown'),(83,5,'hobbit','A',0,'192.168.1.50','unknown'),(84,5,'kickstart','A',0,'192.168.1.45','unknown'),(85,5,'ldap','A',0,'192.168.1.25','unknown'),(86,5,'ldap01','A',0,'192.168.1.35','unknown'),(87,5,'ldap02','A',0,'192.168.1.36','unknown'),(88,5,'ldap03','A',0,'192.168.1.37','unknown'),(89,5,'ldap04','A',0,'192.168.1.38','unknown'),(90,5,'mail01','A',0,'192.168.1.22','unknown'),(91,5,'mail02','A',0,'192.168.1.23','unknown'),(92,5,'mysql','A',0,'192.168.1.55','unknown'),(93,5,'playstation','A',0,'192.168.1.161','unknown'),(94,5,'router','A',0,'192.168.1.254','unknown'),(95,5,'slackware','A',0,'192.168.1.47','unknown'),(96,5,'slayer','A',0,'192.168.1.44','unknown'),(97,5,'somali','A',0,'192.168.1.115','unknown'),(98,5,'ubuntu','A',0,'192.168.1.46','unknown'),(99,5,'weezer','A',0,'192.168.1.14','unknown'),(100,5,'www','A',0,'192.168.1.32','unknown'),(101,5,'@','A',0,'192.168.1.10','unknown'),(102,5,'shihad','CNAME',0,'@','unknown'),(103,5,'caley','CNAME',0,'inverness.scots','unknown'),(104,5,'dons','CNAME',0,'aberdeen.scots','unknown'),(105,5,'estate','CNAME',0,'cmdb','unknown'),(106,5,'hibs','CNAME',0,'hibernian.scots','unknown'),(107,5,'killie','CNAME',0,'kilmarnock.scots','unknown'),(108,5,'rt','CNAME',0,'hibernian.scots','unknown'),(109,5,'twiki','CNAME',0,'www','unknown'),(110,5,'well','CNAME',0,'motherwell.scots','unknown'),(111,4,'hibernian','A',0,'192.168.1.125','unknown'),(112,4,'inverness','A',0,'192.168.1.126','unknown'),(113,4,'kilmarnock','A',0,'192.168.1.123','unknown'),(115,4,'motherwell','A',0,'192.168.1.122','unknown'),(116,4,'rangers','A',0,'192.168.1.124','unknown'),(117,4,'st-mirren','A',0,'192.168.1.132','unknown'),(122,19,'ftp','A',0,'192.168.1.130','yes'),(123,19,'@','MX',10,'mail.newmilnsbarbers.co.uk.','yes'),(125,19,'mail','A',0,'31.193.135.155','unknown'),(128,19,'ns1','A',0,'192.168.1.1','unknown'),(129,19,'ns2','A',0,'192.168.1.120','unknown'),(130,19,'dev','A',0,'192.168.1.32','unknown'),(131,19,'smtp','A',0,'109.109.129.191','unknown'),(132,15,'www','A',0,'31.193.135.155','unknown'),(133,15,'mail','A',0,'31.193.135.155','unknown'),(134,15,'smtp','A',0,'109.109.129.191','unknown'),(135,15,'mail','A',0,'31.193.135.155','unknown'),(136,4,'www','CNAME',0,'@','unknown'),(137,15,'dev','CNAME',0,'cmdb-dev.shihad.org.','unknown'),(138,5,'*.weezer','CNAME',0,'weezer.shihad.org.','unknown'),(139,5,'@','MX',10,'mail.thargoid.co.uk.','unknown'),(140,4,'stranrar','A',0,'192.168.1.134','unknown'),(141,4,'livingston','A',0,'192.168.1.127','unknown'),(142,12,'www','A',0,'109.109.129.191','unknown'),(144,19,'www','A',0,'31.193.135.155','unknown'),(149,5,'thargoid-vps','CNAME',0,'www.thargoid.co.uk.','unknown'),(150,5,'shihad-vps','CNAME',0,'smtp.thargoid.co.uk.','unknown'),(151,5,'alanis','A',0,'192.168.1.9','unknown'),(152,4,'docs','CNAME',0,'@','unknown'),(153,13,'clyde','A',0,'192.168.1.200','unknown'),(154,4,'montrose','A',0,'192.168.1.128','unknown'),(155,20,'ns1','A',0,'192.168.1.120','yes'),(156,20,'ns2','A',0,'192.168.1.122','yes'),(157,20,'mail','A',0,'192.168.1.140','yes'),(158,20,'www','A',0,'192.168.1.130','yes'),(159,20,'ftp','A',0,'192.168.1.130','yes'),(160,20,'@','MX',10,'mail.ailsatech.net.','yes'),(161,12,'ldap01','A',0,'192.168.1.35','unknown'),(162,5,'*.alanis','CNAME',0,'alanis','unknown'),(163,17,'weezer','A',0,'192.168.50.1','unknown'),(164,17,'liverpool','A',0,'192.168.50.2','unknown'),(165,17,'newcastle','A',0,'192.168.50.3','unknown'),(166,17,'arsenal','A',0,'192.168.50.4','unknown'),(167,17,'sunderland','A',0,'192.168.50.5','unknown');
/*!40000 ALTER TABLE `records` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:05
