-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `linux`
--

DROP TABLE IF EXISTS `linux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linux` (
  `name` varchar(40) DEFAULT NULL,
  `ip_address` varchar(15) DEFAULT NULL,
  `mac_address` varchar(17) DEFAULT NULL,
  `kernel` varchar(30) DEFAULT NULL,
  `hostid` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linux`
--

LOCK TABLES `linux` WRITE;
/*!40000 ALTER TABLE `linux` DISABLE KEYS */;
INSERT INTO `linux` VALUES ('rialto.shihad.org','192.168.1.1','00:e0:61:16:5f:c2','2.6.35-32-generic','007f0100'),('shihad.org','192.168.1.10','00:e0:61:16:5f:c2','2.6.35-32-generic','007f0100'),('mail.shihad.org','192.168.1.11','00:e0:61:16:5f:c2','2.6.35-32-generic','007f0100'),('weezer.shihad.org','192.168.1.14','74:ea:3a:80:ae:55','2.6.32-5-amd64','a8c00e01'),('cmdb2.shihad.org','192.168.1.20','52:54:00:66:d4:e9','2.6.32-5-amd64','007f0101'),('cmdb.shihad.org','192.168.1.21','52:54:00:66:d4:e9','2.6.32-5-amd64','007f0101'),('www.shihad.org','192.168.1.32','52:54:00:66:d4:e9','2.6.32-5-amd64','007f0101'),('ldap01.shihad.org','192.168.1.35','52:54:00:4b:a1:0d','2.6.32-5-amd64','007f0101'),('ldap02.shihad.org','192.168.1.36','52:54:00:08:ca:81','2.6.32-5-amd64','a8c07b01'),('kickstart.shihad.org','192.168.1.45','00:e0:61:16:5f:c2','2.6.35-32-generic','007f0100'),('debian.shihad.org','192.168.1.48','00:e0:61:16:5f:c2','2.6.35-32-generic','007f0100'),('hobbit.shihad.org','192.168.1.50','52:54:00:09:AF:86','2.6.37.6-smp','a8c08701'),('mysql.shihad.org','192.168.1.55','52:54:00:4b:a1:0d','2.6.32-5-amd64','007f0101'),('aberdeen.scots.shihad.org','192.168.1.120','','',''),('celtic.scots.shihad.org','192.168.1.121','52:54:00:66:d4:e9','2.6.32-5-amd64','007f0101'),('motherwell.scots.shihad.org','192.168.1.122','52:54:00:AF:B7:23','2.6.32-220.4.2.el6.x86_64','a8c07a01'),('kilmarnock.scots.shihad.org','192.168.1.123','52:54:00:08:ca:81','2.6.32-5-amd64','a8c07b01'),('rangers.scots.shihad.org','192.168.1.124','52:54:00:C1:E1:5D','2.6.18-274.18.1.el5','a8c07c01'),('dundee.scots.shihad.org','192.168.1.129','52:54:00:4b:a1:0d','2.6.32-5-amd64','007f0101'),('scots.shihad.org','192.168.1.130','52:54:00:66:d4:e9','2.6.32-5-amd64','007f0101'),('falkirk.scots.shihad.org','192.168.1.135','52:54:00:09:AF:86','2.6.37.6-smp','a8c08701'),('mail01.scots.shihad.org','192.168.1.140','52:54:00:08:ca:81','2.6.32-5-amd64','a8c07b01'),('mail02.scots.shihad.org','192.168.1.141','52:54:00:4b:a1:0d','2.6.32-5-amd64','007f0101');
/*!40000 ALTER TABLE `linux` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:04
