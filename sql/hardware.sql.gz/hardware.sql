-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hardware`
--

DROP TABLE IF EXISTS `hardware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hardware` (
  `hard_id` int(7) NOT NULL AUTO_INCREMENT,
  `detail` varchar(50) DEFAULT NULL,
  `device` varchar(30) DEFAULT NULL,
  `server_id` int(7) DEFAULT NULL,
  `hard_type_id` int(7) DEFAULT NULL,
  PRIMARY KEY (`hard_id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hardware`
--

LOCK TABLES `hardware` WRITE;
/*!40000 ALTER TABLE `hardware` DISABLE KEYS */;
INSERT INTO `hardware` VALUES (1,'52:54:00:d1:36:a7','eth0',1,1),(13,'52:54:00:09:AF:86','eth0',22,1),(14,'52:54:00:08:ca:81','eth0',7,1),(15,'8 GB','vda',7,2),(16,'1','',7,3),(17,'256 MB','',7,4),(18,'52:54:00:05:06:69','eth0',6,1),(19,'52:54:00:4b:a1:0d','eth0',3,1),(20,'20 GB','vda',3,2),(21,'512 MB','',3,4),(22,'1','',3,3),(23,'00:1d:7d:5c:69:fb','eth0',24,1),(24,'10 GB','vda',2,2),(25,'52:54:00:66:d4:e9','eth0',2,1),(26,'256 MB','',2,4),(27,'1','',2,3),(28,'1','',5,3),(31,'ac97','',5,8),(32,'52:54:00:9d:80:da','eth0',26,1),(33,'20 GB','vda',26,2),(34,'52:54:00:af:b7:23','eth0',12,1),(35,'1 2.7GHz','',1,3),(37,'10 GB','vda',1,2),(38,'128 MB','',1,4),(39,'15GB','vda',12,2),(40,'512 MB','',12,4),(41,'1','',12,3),(46,'52:54:00:ac:ec:17','eth0',29,1),(47,'10 GB','vda',29,2),(48,'512 MB','',29,4),(49,'52:54:00:7c:54:c8','eth0',30,1),(50,'10 GB','vda',30,2),(51,'256 MB','',30,4),(52,'1','',30,3),(53,'52:54:00:e3:af:d2','eth0',31,1),(54,'10 GB','vda',31,2),(55,'512 MB','',31,4),(56,'1','',31,3),(57,'52:54:00:73:d7:bf','eth0',5,1),(58,'52:54:00:7d:47:2a','eth0',11,1),(59,'52:54:00:26:4d:2f','eth0',20,1),(60,'52:54:00:11:a9:e5','eth0',33,1),(61,'15 GB','vda',33,2),(63,'512 MB','',5,4),(64,'15 GB','vda',5,2),(69,'52:54:00:61:32:ec','eth0',35,1),(70,'20 GB','vda',35,2),(71,'1','',35,3),(72,'256 MB','',35,4),(73,'52:54:00:ee:cf:e9','eth0',36,1),(74,'20 GB','vda',36,2),(75,'1','',36,3),(76,'512 MB','',36,4),(81,'52:54:00:61:32:ec','eth0',41,1),(82,'400 GB','vda',41,2),(83,'52:54:00:c5:f6:1f','eth0',42,1),(84,'10 GB','vda',42,2),(85,'52:54:00:ca:17:f0','eth0',43,1),(86,'15 GB','vda',43,2),(87,'24 GB','vda',11,2);
/*!40000 ALTER TABLE `hardware` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:04
