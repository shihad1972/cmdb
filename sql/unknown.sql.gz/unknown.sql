-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `unknown`
--

DROP TABLE IF EXISTS `unknown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unknown` (
  `name` varchar(20) DEFAULT NULL,
  `ip_address` varchar(15) DEFAULT NULL,
  `mac_address` varchar(17) DEFAULT NULL,
  `kernel` varchar(30) DEFAULT NULL,
  `hostid` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unknown`
--

LOCK TABLES `unknown` WRITE;
/*!40000 ALTER TABLE `unknown` DISABLE KEYS */;
INSERT INTO `unknown` VALUES ('spacer.shihad.org','192.168.1.2',' ',' ',' '),('brasco.shihad.org','192.168.1.3',' ',' ',' '),('basque.shihad.org','192.168.1.4',' ',' ',' '),('feeder.shihad.org','192.168.1.5',' ',' ',' '),('primus.shihad.org','192.168.1.6',' ',' ',' '),('acid.shihad.org','192.168.1.7',' ',' ',' '),('arctic.shihad.org','192.168.1.8',' ',' ',' '),('oasis.shihad.org','192.168.1.12',' ',' ',' '),('bauhaus.shihad.org','192.168.1.13',' ',' ',' '),('phoenix.shihad.org','192.168.1.15',' ',' ',' '),('thargoid.shihad.org','192.168.1.16',' ',' ',' '),('php.shihad.org','192.168.1.17',' ',' ',' '),('python.shihad.org','192.168.1.18',' ',' ',' '),('ldap.shihad.org','192.168.1.25',' ',' ',' '),('ldap03.shihad.org','192.168.1.37',' ',' ',' '),('ldap04.shihad.org','192.168.1.38',' ',' ',' '),('zoltan.shihad.org','192.168.1.41',' ',' ',' '),('slayer.shihad.org','192.168.1.44',' ',' ',' '),('apache.shihad.org','192.168.1.70',' ',' ',' '),('windows.shihad.org','192.168.1.103',' ',' ',' '),('somali.shihad.org','192.168.1.115',' ',' ',' '),('hibernian.scots.shih','192.168.1.125',' ',' ',' '),('inverness.scots.shih','192.168.1.126',' ',' ',' '),('livingston.scots.shi','192.168.1.127',' ',' ',' '),('hamilton.scots.shiha','192.168.1.131',' ',' ',' '),('st-mirren.scots.shih','192.168.1.132',' ',' ',' '),('dunfermline.scots.sh','192.168.1.133',' ',' ',' '),('morton.scots.shihad.','192.168.1.134',' ',' ',' '),('fish.shihad.org','192.168.1.150',' ',' ',' '),('snapper.fish.shihad.','192.168.1.200',' ',' ',' '),('trout.fish.shihad.or','192.168.1.201',' ',' ',' '),('pike.fish.shihad.org','192.168.1.202',' ',' ',' '),('salmon.fish.shihad.o','192.168.1.203',' ',' ',' '),('router.shihad.org','192.168.1.254',' ',' ',' ');
/*!40000 ALTER TABLE `unknown` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:05
