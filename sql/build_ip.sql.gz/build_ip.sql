-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `build_ip`
--

DROP TABLE IF EXISTS `build_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build_ip` (
  `ip_id` int(7) NOT NULL AUTO_INCREMENT,
  `ip` int(4) unsigned DEFAULT NULL,
  `hostname` varchar(30) DEFAULT NULL,
  `domainname` varchar(150) DEFAULT NULL,
  `bd_id` int(7) NOT NULL,
  PRIMARY KEY (`ip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `build_ip`
--

LOCK TABLES `build_ip` WRITE;
/*!40000 ALTER TABLE `build_ip` DISABLE KEYS */;
INSERT INTO `build_ip` VALUES (36,3232235896,'aberdeen','scots.shihad.org',2),(37,3232235901,'hibernian','scots.shihad.org',2),(38,3232235907,'hamilton','scots.shihad.org',2),(41,3232235909,'dunfermline','scots.shihad.org',2),(43,3232235911,'falkirk','scots.shihad.org',2),(45,3232235897,'celtic','scots.shihad.org',2),(46,3232235905,'dundee','scots.shihad.org',2),(47,3232235900,'rangers','scots.shihad.org',2),(48,3232235902,'inverness','scots.shihad.org',2),(49,3232235790,'weezer','shihad.org',4),(50,3232235899,'kilmarnock','scots.shihad.org',2),(51,3232235903,'livingston','scots.shihad.org',2),(52,3232235898,'motherwell','scots.shihad.org',2),(54,3232235996,'bolton','epl.shihad.org',3),(55,3232235997,'chelsea','epl.shihad.org',3),(57,3232235999,'everton','epl.shihad.org',3),(58,3232235786,'shihad','shihad.org',4),(60,3232235904,'montrose','scots.shihad.org',2),(61,3232248323,'newcastle','epl.shihad.org',3),(62,3232235906,'www','scots.shihad.org',2),(63,3232235916,'mail01','scots.shihad.org',2),(64,3232235917,'mail02','scots.shihad.org',2),(72,3232248322,'liverpool','epl.shihad.org',3),(83,3232248327,'hamilton','epl.shihad.org',3),(84,3232248324,'arsenal','epl.shihad.org',3),(85,3232248325,'sunderland','epl.shihad.org',3);
/*!40000 ALTER TABLE `build_ip` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:04
