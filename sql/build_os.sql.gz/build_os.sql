-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `build_os`
--

DROP TABLE IF EXISTS `build_os`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build_os` (
  `os_id` int(7) NOT NULL AUTO_INCREMENT,
  `os` varchar(25) DEFAULT NULL,
  `os_version` varchar(25) DEFAULT NULL,
  `alias` varchar(20) DEFAULT NULL,
  `ver_alias` varchar(25) NOT NULL DEFAULT 'none',
  `arch` varchar(12) DEFAULT NULL,
  `boot_id` int(7) DEFAULT NULL,
  `bt_id` int(7) DEFAULT NULL,
  PRIMARY KEY (`os_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `build_os`
--

LOCK TABLES `build_os` WRITE;
/*!40000 ALTER TABLE `build_os` DISABLE KEYS */;
INSERT INTO `build_os` VALUES (1,'Centos','5.0','centos','none','i386',3,3),(2,'Redhat','5.0','redhat','none','i386',5,4),(3,'Ubuntu','08.04','ubuntu','hardy','i386',4,2),(5,'Slackware','12.0','slack','none','i386',9,5),(6,'Centos','5.1','centos','none','i386',3,3),(7,'Centos','5.2','centos','none','i386',3,3),(8,'Centos','5.3','centos','none','i386',3,3),(9,'Centos','5.4','centos','none','i386',3,3),(10,'Centos','5.5','centos','none','i386',3,3),(11,'Redhat','5.1','redhat','none','i386',5,4),(12,'Debian','6.0','debian','squeeze','i386',2,1),(13,'Ubuntu','08.10','ubuntu','interpid','i386',4,2),(14,'Ubuntu','09.04','ubuntu','jaunty','i386',6,2),(15,'Ubuntu','09.10','ubuntu','karmic','i386',6,2),(16,'Ubuntu','10.04','ubuntu','lucid','i386',7,2),(17,'Ubuntu','10.10','ubuntu','maverick','i386',7,2),(18,'Slackware','12.1','slack','none','i386',9,5),(19,'Slackware','12.2','slack','none','i386',9,5),(20,'Slackware','13.0','slack','none','i386',9,5),(21,'Slackware','13.1','slack','none','i386',9,5),(23,'Centos','5.6','centos','none','i386',3,3),(24,'Slackware','13.37','slack','none','i386',9,5),(29,'Centos','6.0','centos','none','i386',10,3),(30,'Centos','6.0','centos','none','x86_64',10,3),(31,'Redhat','6.0','redhat','none','i386',5,4),(32,'Redhat','6.0','redhat','none','x86_64',5,4),(33,'Ubuntu','11.04','ubuntu','natty','i386',11,2),(36,'Centos','5.7','centos','none','i386',3,3),(37,'Ubuntu','11.04','ubuntu','natty','x86_64',11,2),(38,'Ubuntu','11.10','ubuntu','oneiric','i386',11,2),(39,'Ubuntu','11.10','ubuntu','oneiric','x86_64',11,2),(40,'Debian','6.0','debian','squeeze','x86_64',2,1),(41,'Centos','6.1','centos','none','i386',10,3),(42,'Centos','6.1','centos','none','x86_64',10,3),(43,'Centos','6.2','centos','none','x86_64',10,3),(44,'Centos','6.2','centos','none','i386',10,3),(45,'Debian','5.0','debian','lenny','i386',13,1),(46,'Debian','5.0','debian','lenny','x86_64',13,1),(47,'Redhat','6.1','redhat','none','x86_64',12,4),(48,'Slackware','14.0','slack','none','i386',14,5),(50,'Slackware','14.0','slack','none','x86_64',14,5),(51,'Centos','6.3','centos','none','i386',10,3),(52,'Centos','6.3','centos','none','x86_64',10,3),(53,'Debian','6.9','debian','wheezy','i386',2,1),(54,'Debian','6.9','debian','wheezy','x86_64',2,1),(55,'Ubuntu','12.04','ubuntu','precise','x86_64',16,2),(56,'Ubuntu','12.04','ubuntu','precise','i386',16,2);
/*!40000 ALTER TABLE `build_os` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:04
