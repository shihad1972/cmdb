-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `seed_part`
--

DROP TABLE IF EXISTS `seed_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seed_part` (
  `part_id` int(7) NOT NULL AUTO_INCREMENT,
  `minimum` int(7) NOT NULL,
  `maximum` int(7) NOT NULL,
  `priority` int(7) NOT NULL DEFAULT '0',
  `mount_point` varchar(64) NOT NULL,
  `filesystem` varchar(16) NOT NULL,
  `server_id` int(7) NOT NULL,
  `logical_volume` varchar(16) NOT NULL DEFAULT 'none',
  PRIMARY KEY (`part_id`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seed_part`
--

LOCK TABLES `seed_part` WRITE;
/*!40000 ALTER TABLE `seed_part` DISABLE KEYS */;
INSERT INTO `seed_part` VALUES (5,64,300,512,'swap','linux-swap',10,'swap'),(6,500,10000,800,'/var','ext4',10,'var'),(7,500,10000,1000,'/','ext4',10,'root'),(8,40,250,150,'/boot','ext4',10,'none'),(10,40,350,250,'/boot','ext4',3,'none'),(11,500,1000000000,6500,'/','ext4',3,'root'),(12,500,5500,4000,'/var','ext4',3,'var'),(13,64,300,512,'swap','linux-swap',3,'swap'),(14,64,200,512,'swap','linux-swap',36,'swap'),(15,500,1000,1000,'/','ext4',36,'root'),(16,500,1000,700,'/var','ext4',36,'var'),(17,128,300,500,'/boot','ext4',36,'none'),(25,5120,2147483647,100,'/','ext4',31,'root_lv'),(26,4096,10240,90,'/var','ext4',31,'var_lv'),(27,1024,1024,100,'swap','swap',31,'swap_lv'),(28,256,512,100,'/boot','ext4',31,'boot'),(46,5120,2147483647,100,'/','ext4',1,'root_lv'),(47,4096,10240,90,'/var','ext4',1,'var_lv'),(48,1024,1024,100,'swap','swap',1,'swap_lv'),(49,256,512,100,'/boot','ext4',1,'boot'),(50,5120,2147483647,100,'/','ext4',5,'root_lv'),(51,4096,10240,90,'/var','ext4',5,'var_lv'),(52,1024,1024,100,'swap','swap',5,'swap_lv'),(53,256,512,100,'/boot','ext4',5,'boot'),(58,5120,2147483647,100,'/','ext4',20,'root_lv'),(59,4096,10240,90,'/var','ext4',20,'var_lv'),(60,1024,1024,100,'swap','swap',20,'swap_lv'),(61,256,512,100,'/boot','ext4',20,'boot'),(62,5120,2147483647,100,'/','ext4',22,'root_lv'),(63,4096,10240,90,'/var','ext4',22,'var_lv'),(64,1024,1024,100,'swap','swap',22,'swap_lv'),(65,256,512,100,'/boot','ext4',22,'boot'),(66,5120,2147483647,100,'/','ext4',2,'root_lv'),(67,4096,10240,90,'/var','ext4',2,'var_lv'),(68,1024,1024,100,'swap','swap',2,'swap_lv'),(69,256,512,100,'/boot','ext4',2,'boot'),(70,5120,2147483647,100,'/','ext4',3,'root_lv'),(71,4096,10240,90,'/var','ext4',3,'var_lv'),(72,1024,1024,100,'swap','swap',3,'swap_lv'),(73,256,512,100,'/boot','ext4',3,'boot'),(74,5120,2147483647,100,'/','ext4',10,'root_lv'),(75,4096,10240,90,'/var','ext4',10,'var_lv'),(76,1024,1024,100,'swap','swap',10,'swap_lv'),(77,256,512,100,'/boot','ext4',10,'boot'),(78,5120,2147483647,100,'/','ext4',6,'root_lv'),(79,4096,10240,90,'/var','ext4',6,'var_lv'),(80,1024,1024,100,'swap','swap',6,'swap_lv'),(81,256,512,100,'/boot','ext4',6,'boot'),(82,5120,2147483647,100,'/','ext4',24,'root_lv'),(83,4096,10240,90,'/var','ext4',24,'var_lv'),(84,1024,1024,100,'swap','swap',24,'swap_lv'),(85,256,512,100,'/boot','ext4',24,'boot'),(86,5120,2147483647,100,'/','ext4',7,'root_lv'),(87,4096,10240,90,'/var','ext4',7,'var_lv'),(88,1024,1024,100,'swap','swap',7,'swap_lv'),(89,256,512,100,'/boot','ext4',7,'boot'),(90,5120,2147483647,100,'/','ext4',26,'root_lv'),(91,4096,10240,90,'/var','ext4',26,'var_lv'),(92,1024,1024,100,'swap','swap',26,'swap_lv'),(93,256,512,100,'/boot','ext4',26,'boot'),(94,5120,2147483647,100,'/','ext4',12,'root_lv'),(95,4096,10240,90,'/var','ext4',12,'var_lv'),(96,1024,1024,100,'swap','swap',12,'swap_lv'),(97,256,512,100,'/boot','ext4',12,'boot'),(98,5120,2147483647,100,'/','ext4',29,'root_lv'),(99,4096,10240,90,'/var','ext4',29,'var_lv'),(100,1024,1024,100,'swap','swap',29,'swap_lv'),(101,256,512,100,'/boot','ext4',29,'boot'),(102,5120,2147483647,100,'/','ext4',30,'root_lv'),(103,4096,10240,90,'/var','ext4',30,'var_lv'),(104,1024,1024,100,'swap','swap',30,'swap_lv'),(105,256,512,100,'/boot','ext4',30,'boot'),(106,5120,2147483647,100,'/','ext4',33,'root_lv'),(107,4096,10240,90,'/var','ext4',33,'var_lv'),(108,1024,1024,100,'swap','swap',33,'swap_lv'),(109,256,512,100,'/boot','ext4',33,'boot'),(110,5120,2147483647,100,'/','ext4',16,'root_lv'),(111,4096,10240,90,'/var','ext4',16,'var_lv'),(112,1024,1024,100,'swap','swap',16,'swap_lv'),(113,256,512,100,'/boot','ext4',16,'boot'),(114,5120,2147483647,100,'/','ext4',35,'root_lv'),(115,4096,10240,90,'/var','ext4',35,'var_lv'),(116,1024,1024,100,'swap','swap',35,'swap_lv'),(117,256,512,100,'/boot','ext4',35,'boot'),(118,5120,2147483647,100,'/','ext4',36,'root_lv'),(119,4096,10240,90,'/var','ext4',36,'var_lv'),(120,1024,1024,100,'swap','swap',36,'swap_lv'),(121,256,512,100,'/boot','ext4',36,'boot'),(122,5120,2147483647,100,'/','ext4',31,'root_lv'),(123,4096,10240,90,'/var','ext4',31,'var_lv'),(124,1024,1024,100,'swap','swap',31,'swap_lv'),(125,256,512,100,'/boot','ext4',31,'boot'),(229,5120,2147483647,100,'/','ext4',11,'root_lv'),(230,4096,10240,90,'/var','ext4',11,'var_lv'),(231,1024,1024,100,'swap','swap',11,'swap_lv'),(232,256,512,100,'/boot','ext4',11,'boot'),(236,5120,10240,100,'/','ext4',42,'rootlv'),(237,3096,5120,80,'/var','ext4',42,'varlv'),(238,512,2048,70,'swap','swap',42,'swaplv'),(239,512,1024,60,'/boot','ext4',42,'boot'),(243,5120,10240,100,'/','ext4',43,'rootlv'),(244,3096,5120,80,'/var','ext4',43,'varlv'),(245,512,2048,70,'swap','swap',43,'swaplv'),(246,512,1024,60,'/boot','ext4',43,'boot');
/*!40000 ALTER TABLE `seed_part` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:05
