-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `locale`
--

DROP TABLE IF EXISTS `locale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locale` (
  `locale_id` int(7) NOT NULL AUTO_INCREMENT,
  `locale` varchar(32) NOT NULL DEFAULT 'en_GB',
  `country` varchar(16) NOT NULL DEFAULT 'GB',
  `language` varchar(16) NOT NULL DEFAULT 'en',
  `keymap` varchar(16) NOT NULL DEFAULT 'uk',
  `os_id` int(7) NOT NULL,
  `bt_id` int(7) NOT NULL,
  `timezone` varchar(63) NOT NULL DEFAULT 'Europe/London',
  PRIMARY KEY (`locale_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locale`
--

LOCK TABLES `locale` WRITE;
/*!40000 ALTER TABLE `locale` DISABLE KEYS */;
INSERT INTO `locale` VALUES (1,'en_GB.UTF-8','GB','en','uk',12,1,'Europe/London'),(2,'en_GB.UTF-8','GB','en','uk',40,1,'Europe/London'),(3,'en_GB.UTF-8','GB','en','uk',45,1,'Europe/London'),(4,'en_GB.UTF-8','GB','en','uk',46,1,'Europe/London'),(5,'en_GB.UTF-8','GB','en','uk',53,1,'Europe/London'),(6,'en_GB.UTF-8','GB','en','uk',54,1,'Europe/London'),(7,'en_GB.UTF-8','GB','en','uk',55,1,'Europe/London'),(8,'en_GB.UTF-8','GB','en','uk',56,1,'Europe/London'),(12,'en_GB','GB','en','uk',1,3,'Europe/London'),(13,'en_GB','GB','en','uk',6,3,'Europe/London'),(14,'en_GB','GB','en','uk',7,3,'Europe/London'),(15,'en_GB','GB','en','uk',8,3,'Europe/London'),(16,'en_GB','GB','en','uk',9,3,'Europe/London'),(17,'en_GB','GB','en','uk',10,3,'Europe/London'),(18,'en_GB','GB','en','uk',23,3,'Europe/London'),(19,'en_GB','GB','en','uk',29,3,'Europe/London'),(20,'en_GB','GB','en','uk',30,3,'Europe/London'),(21,'en_GB','GB','en','uk',36,3,'Europe/London'),(22,'en_GB','GB','en','uk',41,3,'Europe/London'),(23,'en_GB','GB','en','uk',42,3,'Europe/London'),(24,'en_GB','GB','en','uk',43,3,'Europe/London'),(25,'en_GB','GB','en','uk',44,3,'Europe/London'),(26,'en_GB','GB','en','uk',51,3,'Europe/London'),(27,'en_GB','GB','en','uk',52,3,'Europe/London');
/*!40000 ALTER TABLE `locale` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:04
