-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `service_id` int(7) NOT NULL AUTO_INCREMENT,
  `server_id` int(7) DEFAULT NULL,
  `cust_id` int(7) DEFAULT NULL,
  `service_type_id` int(7) DEFAULT NULL,
  `detail` varchar(50) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (21,24,3,11,'SMTP service for weezer','weezer.shihad.org'),(22,24,3,14,'Monitor for weezer','xymon.weezer.shihad.org'),(23,3,1,16,'LDAP Authentication Service','ldap://ldap01.shihad.org'),(24,7,1,16,'LDAP Authentication Service','ldap://ldap02.shihad.org'),(25,1,1,12,'Web control for DNS admin','http://aberdeen.scots.shihad.org'),(26,12,1,12,'Web control for DNS admin','http://motherwell.scots.shihad.org'),(27,1,1,13,'DNS Admin',''),(28,12,1,13,'DNS Admin',''),(30,5,1,12,'Request Tracker Ticket System','https://hibs.shihad.org/rt/'),(31,16,2,12,'Kickstart Web Repo','http://kickstart.shihad.org'),(32,16,2,12,'Debian Preseed Website','http://debian.shihad.org'),(33,16,2,12,'Ubuntu Preseed Web Repo','http://ubuntu.shihad.org'),(34,5,2,12,'CMDB Web site','http://cmdb.shihad.org'),(35,5,2,12,'Development www.thargoid.co.uk','http://dev.thargoid.co.uk'),(36,5,2,12,'Development cmdb.shihad.org','http://cmdb-dev.shihad.org'),(37,24,2,12,'CMDB Test site','http://cmdb.weezer.shihad.org'),(38,7,2,11,'SMTP Service','smtp://mail01.scots.shihad.org'),(39,3,2,11,'SMTP Service','smtp://mail02.scots.shihad.org'),(40,16,2,11,'SMTP Service','smtp://mail01.shihad.org'),(41,16,2,13,'DNS Resolver',''),(42,12,2,13,'DNS Resolver',''),(43,2,2,12,'Shihad web site','http://www.shihad.org'),(44,2,2,12,'Shihad SSL site with twiki','https://www.shihad.org'),(45,2,8,12,'Development newmilnsbarbers.co.uk','http://dev.newmilnsbarbers.co.uk'),(46,3,1,15,'Main MySQL Database','mysql.shihad.org');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:05
