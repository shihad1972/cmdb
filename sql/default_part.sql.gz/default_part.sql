-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `default_part`
--

DROP TABLE IF EXISTS `default_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `default_part` (
  `def_part_id` int(7) NOT NULL AUTO_INCREMENT,
  `minimum` int(7) NOT NULL,
  `maximum` int(7) NOT NULL,
  `priority` int(7) NOT NULL DEFAULT '0',
  `mount_point` varchar(64) NOT NULL,
  `filesystem` varchar(16) NOT NULL,
  `def_scheme_id` int(7) NOT NULL,
  `logical_volume` varchar(16) NOT NULL DEFAULT 'none',
  PRIMARY KEY (`def_part_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `default_part`
--

LOCK TABLES `default_part` WRITE;
/*!40000 ALTER TABLE `default_part` DISABLE KEYS */;
INSERT INTO `default_part` VALUES (1,5120,10240,100,'/','ext4',10,'none'),(2,3096,6144,85,'/var','ext4',10,'none'),(3,512,1024,50,'/boot','ext4',10,'none'),(4,1024,1024,20,'swap','swap',10,'none'),(5,5120,10240,100,'/','ext4',11,'root_vol'),(6,3096,6144,90,'/var','ext4',11,'var_vol'),(7,1024,1024,80,'swap','swap',11,'swap_vol'),(8,512,2048,60,'/boot','ext4',11,'boot_vol'),(9,5120,2147483647,100,'/','ext4',12,'root_lv'),(10,4096,10240,90,'/var','ext4',12,'var_lv'),(11,1024,1024,100,'swap','swap',12,'swap_lv'),(12,256,512,100,'/boot','ext4',12,'boot'),(13,5120,10240,100,'/','ext4',13,'rootlv'),(14,3096,5120,80,'/var','ext4',13,'varlv'),(15,512,2048,70,'swap','swap',13,'swaplv'),(16,512,1024,60,'/boot','ext4',13,'boot');
/*!40000 ALTER TABLE `default_part` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:04
