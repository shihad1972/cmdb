-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (i486)
--
-- Host: mysql.shihad.org    Database: cmdbdev
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `boot_line`
--

DROP TABLE IF EXISTS `boot_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boot_line` (
  `boot_id` int(7) NOT NULL AUTO_INCREMENT,
  `os` varchar(25) DEFAULT NULL,
  `os_ver` varchar(25) DEFAULT NULL,
  `bt_id` int(7) DEFAULT NULL,
  `boot_line` varchar(150) NOT NULL DEFAULT 'none',
  PRIMARY KEY (`boot_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boot_line`
--

LOCK TABLES `boot_line` WRITE;
/*!40000 ALTER TABLE `boot_line` DISABLE KEYS */;
INSERT INTO `boot_line` VALUES (2,'debian','6',1,'auto=true priority=critical vga=788'),(3,'centos','5',3,'ksdevice=eth0 console=tty0 ramdisk_size=8192'),(4,'ubuntu','08',2,'country=GB console-setup/layoutcode=gb auto=true priority=critical vga=788'),(5,'redhat','5',4,'ksdevice=eth0 console=tty0 ramdisk_size=8192'),(6,'ubuntu','09',2,'country=GB console-setup/layoutcode=gb auto=true priority=critical vga=788'),(7,'ubuntu','10',2,'country=GB console-setup/layoutcode=gb auto=true priority=critical vga=788'),(9,'slack','all',5,'none'),(10,'centos','6',3,'ksdevice=eth0 console=tty0 ramdisk_size=8192'),(11,'ubuntu','11',2,'country=GB console-setup/layoutcode=gb auto=true priority=critical vga=788'),(12,'redhat','6',4,'ksdevice=eth0 console=tty0 ramdisk_size=8192'),(13,'debian','5',1,'auto=true priority=critical vga=788'),(14,'slack','14',5,'none'),(15,'slack','14',5,'none'),(16,'ubuntu','12',2,'auto=true priority=critical vga=788');
/*!40000 ALTER TABLE `boot_line` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-28  1:30:03
